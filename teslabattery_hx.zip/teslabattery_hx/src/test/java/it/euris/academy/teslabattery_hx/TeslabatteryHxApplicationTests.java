package it.euris.academy.teslabattery_hx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeslabatteryHxApplicationTests {

	@Test
	void contextLoads() {
	}

}
